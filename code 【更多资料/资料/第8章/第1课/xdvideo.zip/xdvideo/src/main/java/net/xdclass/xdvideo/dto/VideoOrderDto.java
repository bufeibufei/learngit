package net.xdclass.xdvideo.dto;

import net.xdclass.xdvideo.domain.VideoOrder;

/**
 * 订单数据传输对象
 */
public class VideoOrderDto extends VideoOrder {

}

package net.xdclass.xdvideo.service.impl;

public class VideoServiceImpl {
}

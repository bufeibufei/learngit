package net.xdclass.xdvideo.service;

public interface VideoService {
}
